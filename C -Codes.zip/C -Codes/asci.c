#include<stdio.h>
int main()
{
	char c;
	printf("enter the asci character:");
	scanf("%c",&c);

		printf("ASCI character is =%d\n",c,c);
		return 0;
}

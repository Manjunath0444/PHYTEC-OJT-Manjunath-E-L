#include<stdio.h>
int main(int argc,char *argv[])
{
	printf("number of arguments passed =%d\n",argc);
	printf("argv[0]=%s\n",argv[0]);
}


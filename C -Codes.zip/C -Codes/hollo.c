#include<stdio.h>
void main()
{
	int ptr;
	ptr=_("hello world");
	printf("array is %s\n",ptr);
}


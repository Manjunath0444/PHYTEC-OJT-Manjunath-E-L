#include<stdio.h>
void suum_demo()
{
	int a=10;
	int b=20;
	int sum=30;
	int  avg;
	avg=sum+a+b/4;
	printf("avg is%d\n",avg);
}
int main()
{
	suum_demo();
}


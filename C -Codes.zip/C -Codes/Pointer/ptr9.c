#include<stdio.h>
void minmax(int arr[],int len,int *max,int *min)

{
	*min=*max=arr[0];
	for(int i=1;i<len;i++)
	{
		if(arr[i]>*max)
			*max=arr[i];
		if(arr[i]<*min)
			*min=arr[i];
	}
}
int main()
{
	int max,min;
	int a[]={23,33,45,89,90,67,34,57};
	int len=sizeof a/sizeof(a[0]);
	minmax(a,len,&min,&max);
	printf("maximum and minimum value is %d\n%d\n",min,max);
	return 0;
}

#include<stdio.h>
int main()
{
	int a[]={5,6,7,8,9};
	int sum=0,*p;
	for(p=&a[0];p<=&a[4];p++)
	{
		sum=sum+*p;
	}
	printf("sum is %d",sum);
	return 0;
}


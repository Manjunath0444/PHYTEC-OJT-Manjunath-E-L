#include<stdio.h>
void fun(int,int ,int );
int main()
{
	int x=5,y=8,z=10;
	fun(x,y,z);
	printf("value is %d%d%d\n",x,y,z);
	return 0;
}
void fun (int a,int b,int c)
{
	int d;
	d=a;
	a=b;
	b=c;
	c=a;
printf("valur are a=%d,b=%d\n,c=%d\n",a,b,c);
}


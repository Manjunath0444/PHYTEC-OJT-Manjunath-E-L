#include<stdio.h>
int main()
{
	int a[]={10,20,30,40};
	int *p=a+2;
	printf("%d",*(++p));
			return 0;
			}


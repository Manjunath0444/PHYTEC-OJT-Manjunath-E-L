#include<stdio.h>
int main()
{
	int n=20;
	int count=0;
	for(int i=1;i<=n;i++)
	{

		if(i%n!=0)
		{
			i++;
		}
		printf("%d",i);
	}
}


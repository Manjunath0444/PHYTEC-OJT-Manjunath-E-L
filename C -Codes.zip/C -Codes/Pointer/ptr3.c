#include<stdio.h>
void swapv(int x,int y);
int main()
{
	int a=10,b=20;
	swapv(a,b);
	printf("swaped is %d\n%d\n",a,b);
return 0;
}
void swapv(int x,int y)
{
	int z;
	z=x;
	x=y;
	y=z;
	printf("swaped is %d\n%d\n",x,y);
}

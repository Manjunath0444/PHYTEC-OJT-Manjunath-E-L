#include<stdio.h>
int main()
{
	int a[]={10,20,30,40,50};
	int size=sizeof(a)/sizeof(a[0]);
	int i;
	for(i=0;i<=ize-1;i++)
	printf("%d",a[i]);
	printf("elements of reverse order:");
	for(i=size-1;i>=0;i--)
		printf("%d\n%d\n",a[i],size);
	return 0;
}


#include<stdio.h>
void areaperi( int ,float *area,float *perimeter);
int main()
{
	int radius;
	float area,perimeter;
	printf("enter the radius");
	scanf("%d",&radius);
	areaperi(radius,&area,&perimeter);

	return 0;
}
void areaperi( int r, float *a,float *p)
{
	*a=3.14*r*r;
	*p=2*3.14*r;
	printf("area is %f\n",*a);
	printf("perimeter ids %f\n",*p);
}

#include <stdio.h>

int main() {
    int n = 20;

    for (int i = 2; i <= n; i++) {
        int isPrime = 1; // Assume i is prime

        for (int j = 2; j * j <= i; j++) {
            if (i % j == 0) {
                isPrime = 0; // i is not prime
                break;
            }
        }

        if (isPrime) {
            printf("%d ", i);
        }
    }

    return 0;
}


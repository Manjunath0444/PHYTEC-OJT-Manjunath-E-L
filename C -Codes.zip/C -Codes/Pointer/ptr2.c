#include <stdio.h>

void modifyValue(int *x) {
    *x = *x + 10;
}

int main() {
    int num = 5;
    printf("Before calling modifyValue: %d\n", num);
    modifyValue(&num);
    printf("After calling modifyValue: %d\n", num);
    return 0;
}


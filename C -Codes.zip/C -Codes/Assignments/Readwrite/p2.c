#include <stdio.h>

int main() {
    FILE *file;
    char filename[1000];
    char ch;

    // Input the file name from the user
    printf("Input the file name to be opened: ");
    scanf("%s", filename);

    // Open the file for reading
    file = fopen(filename, "r");

    if (file == NULL) {
        printf("Unable to open the file.\n");
        return 1;
    }

    printf("The content of the file %s is :\n\n", filename);

    // Read and print the file character by character
    while ((ch = fgetc(file)) != EOF) {
        putchar(ch);
    }

    // Close the file
    fclose(file);

    return 0;
}


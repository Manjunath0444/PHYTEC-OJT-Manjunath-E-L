#include <stdio.h>

int main() {
    FILE *file;
    char filename[1000];
    int lineCount = 0;
    char ch;

    // Input the file name from the user
    printf("Input the file name to be opened: ");
    scanf("%s", filename);

    // Open the file for reading
    file = fopen(filename, "r");

    if (file == NULL) {
        printf("Unable to open the file.\n");
        return 1;
    }

    // Count the number of lines in the file
    while ((ch = fgetc(file)) != EOF) {
        if (ch == '\n') {
            lineCount++;
        }
    }

    // Close the file
    fclose(file);

    printf("The lines in the file %s are: %d\n", filename, lineCount + 1);

    return 0;
}


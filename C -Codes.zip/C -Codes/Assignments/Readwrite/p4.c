#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *file;
    char filename[1000];
    char line[1000];
    char *lines[1000]; // Array to store lines
    int lineCount = 0;

    // Input the file name from the user
    printf("Input the file name to be opened: ");
    scanf("%s", filename);

    // Open the file for reading
    file = fopen(filename, "r");

    if (file == NULL) {
        printf("Unable to open the file.\n");
        return 1;
    }

    printf("The content of the file %s are:\n", filename);

    // Read and store lines from the file
    while (fgets(line, sizeof(line), file) != NULL) {
        lines[lineCount] = strdup(line); // Store a copy of the line
        lineCount++;
        printf("%s", line);
    }

    // Close the file
    fclose(file);

    // Print the lines stored in the array
    printf("\nLines stored in the array:\n");
    for (int i = 0; i < lineCount; i++) {
        printf("%s", lines[i]);
        free(lines[i]); // Free the dynamically allocated memory
    }

    return 0;
}


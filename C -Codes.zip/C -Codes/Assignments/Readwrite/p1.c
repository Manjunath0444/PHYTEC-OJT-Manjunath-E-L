#include <stdio.h>

int main() {
    FILE *file;
    char sentence[1000];
    
    // Open a file for writing
    file = fopen("test.txt", "w");

    if (file == NULL) {
        printf("Unable to create the file.\n");
        return 1;
    }

    // Input a sentence from the user
    printf("Input a sentence for the file: ");
    fgets(sentence, sizeof(sentence), stdin);
    fprintf(file, "%s", sentence);
    fclose(file);

    printf("The file test.txt created successfully...!!\n");

    return 0;
}


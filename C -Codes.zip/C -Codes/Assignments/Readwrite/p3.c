#include <stdio.h>

int main() {
    FILE *file;
    char filename[1000];
    int numLines;
    char line[1000];

    // Input the number of lines to be written from the user
    printf("Input the number of lines to be written: ");
    scanf("%d", &numLines);

    // Input file name from the user
    printf("Input the file name to be created: ");
    scanf("%s", filename);

    // Open the file for writing
    file = fopen(filename, "w");

    if (file == NULL) {
        printf("Unable to create the file.\n");
        return 1;
    }

    printf(":: The lines are ::\n");

    // Input and write the specified number of lines to the file
    for (int i = 0; i < numLines; i++) {
        getchar(); // Consume newline character left in the input buffer
        printf("Enter line %d: ", i + 1);
        fgets(line, sizeof(line), stdin);
        fprintf(file, "%s", line);
    }

    // Close the file
    fclose(file);

    // Open the file again for reading and print its content
    file = fopen(filename, "r");

    if (file == NULL) {
        printf("Unable to open the file for reading.\n");
        return 1;
    }

    printf("\nThe content of the file %s is :\n", filename);

    // Read and print the file line by line
    while (fgets(line, sizeof(line), file) != NULL) {
        printf("%s", line);
    }

    // Close the file
    fclose(file);

    return 0;
}


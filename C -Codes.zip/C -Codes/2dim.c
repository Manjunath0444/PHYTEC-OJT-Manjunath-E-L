#include<stdio.h>
void demod_2dim()
{
	char a[6][20]={"rahul","manoj","charan"};
	printf("%s\n",&a[1][0]);
}
int main()
{
	demod_2dim();
}


#include<stdio.h>
void demo_prime()
{
		int i=10;
		if(i%2)
			printf("is prime number");
		else
			printf("is not prime number");
}
int main()
{
	demo_prime();
}

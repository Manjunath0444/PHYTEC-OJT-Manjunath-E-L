#include<stdio.h>
#define SQUARE(x)
#define CUBE(x)
int main()
{
	int r1=SQUARE(6);
	int r2=CUBE(8);
	printf("result is %d\n",r1);
	printf("result is %d\n",r2);
}

#include<stdio.h>
void main()
{
	int n=3;
	while(n>0)
	{
		printf("%d\n",n);
		n--;
	}
}

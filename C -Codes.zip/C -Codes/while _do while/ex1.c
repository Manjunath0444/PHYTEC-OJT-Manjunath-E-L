#include <stdio.h>
int main()
{
int i,j,count;
count=0;
for(i=0; i<5; i++);
{
	for(j=0;j<5;j++);
	{
	    count++;
	}
}
printf("%d",count);
return 0;
}

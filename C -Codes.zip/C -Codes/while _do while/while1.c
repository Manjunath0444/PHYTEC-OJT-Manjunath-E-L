#include<stdio.h>
void main()
{
	int n;
	printf("enter the integer");
	scanf("%d",&n);
	while(n!=0)
		{
			printf("enter an integer");
			scanf("%d",&n);
		}
	printf("out of the loop");
}

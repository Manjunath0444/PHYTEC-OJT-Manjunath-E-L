#include<stdio.h>
void main()
{
	int n=3;
	do
	{
		printf("%d\n",n);
			n--;
	}
	while(n>0);
}
		

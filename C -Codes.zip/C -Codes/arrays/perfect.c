#include<stdio.h>
int main()
{
	int num;
	printf("enter the number:");
	scanf("%d",&num);
	int sum=0;
	for(int i=1;i<=num;i++)
	{
		if(i%num==0)
		{
			sum=sum+1;
		}
		printf("%d\n",sum);
	}
	if(sum==num)
	{
		printf("it is perfect",num);
	}
	else
	{
		printf("it is not perfect",num);
	}
	return 0;
}


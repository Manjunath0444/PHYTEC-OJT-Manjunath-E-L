#include <stdio.h>

int main() {
    printf("Prime numbers between 1 and 20 are:\n");

    for (int i = 2; i <= 20; i++) {
        int isPrime = 1; // Assume i is prime initially

        for (int j = 2; j * j <= i; j++) {
            if (i % j == 0) {
                isPrime = 0; // i is divisible by j, so it's not prime
                break;       // No need to check further
            }
        }

        if (isPrime) {
            printf("%d ", i); // Print the prime number
        }
    }

    printf("\n");

    return 0;
}


#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
int main()
{
	int fd,n;
	char buff[10];
	fd=open("abc.txt",O_RDWR);
	n=read(fd,buff,5);
	write(1,buff,n);
	close(fd);
	int flags=fcntl(fd,F_GETFL,0);
	flags=flags|O_APPEND;
	fd=open("abc.txt",O_RDONLY);
	fcntl(fd,F_SETFL,flags);
	return 0;
}

	

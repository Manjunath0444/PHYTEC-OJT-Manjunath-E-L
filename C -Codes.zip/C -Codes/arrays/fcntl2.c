#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

int main() {
    int fd, n;
    char buff[10];

    // Open the file in append mode (O_APPEND)
    fd = open("abc.txt", O_RDWR | O_APPEND);

    if (fd == -1) {
        perror("open");
        return 1;
    }

    n = read(fd, buff, 5);
    write(1, buff, n);
    close(fd);

    return 0;
}


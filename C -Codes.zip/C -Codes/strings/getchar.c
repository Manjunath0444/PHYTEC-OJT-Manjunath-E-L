#include<stdio.h>
int fun(char str[],int n)
{
	int ch;
	int i=0;
	while((ch=getchar())!='\n')
	{
		if (i<n)
			str[i++]=ch;
		}
str[i]='\0';
return i;
}
	int main()
	{
		char str[100];
		int n=fun(str,n);
		printf("entar teh string");
		scanf("%s",&str);
		printf("%d %s",n,str);
		return 0;
	}



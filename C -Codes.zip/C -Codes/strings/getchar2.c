#include<stdio.h>

int fun(char str[], int n) {
    int ch;
    int i = 0;
    while ((ch = getchar()) != '\n') {
        if (i < n) {
            str[i++] = ch;
        }
    }
    str[i] = '\0';
    return i;
}

int main() {
    char str[100];
    int n;
    
    n = fun(str, sizeof(str)); // Read the string using fun

    printf("%d,%s", n, str); // Print the length and the string

    return 0;
}


#include<stdio.h>
int main()
{
	char a[20]="c pr0gramming";
	char b[20];
	int len=0;
	for(int i=0;a[i]!='\0';i++)
	{
		len++;
	}
	for(int i=0;i<=len;i++)
	{
		b[i]=a[i];
	}
	b[len]='\0';
	printf("copy the string is%s\n",b);
	return 0;
}


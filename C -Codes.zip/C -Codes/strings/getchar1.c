#include <stdio.h>

int fun(char str[], int n) {
    int ch;
    int i = 0;
    while ((ch = getchar()) != '\n') {
        if (i < n)
            str[i++] = ch;
    }
    str[i] = '\0';
    return i;
}

int main() {
    char str[100];
    int n = sizeof(str); // Initialize n with the size of the str array

    printf("Enter the string: ");
    n = fun(str, n); // Pass the size of the buffer to the function

    printf("Length: %d\n", n);
    printf("String: %s\n", str);

    return 0;
}


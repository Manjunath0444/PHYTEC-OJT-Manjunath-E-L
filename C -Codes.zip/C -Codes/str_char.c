#include<stdio.h>
void str_char()
{
      


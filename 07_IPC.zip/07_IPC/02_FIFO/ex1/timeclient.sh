#!/bin/bash
cat /tmp/time_fifo

void delayms(int n);

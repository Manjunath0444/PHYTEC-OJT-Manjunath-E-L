#include<stdio.h>
#include<stdlib.h>
int main()
{
	demo_arm();
}


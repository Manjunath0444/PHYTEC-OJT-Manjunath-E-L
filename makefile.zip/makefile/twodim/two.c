#include<stdio.h>
int main()
{
	demod_2dim();
}


#include<stdio.h>
void demo_prime()
{
	int i;
	if(i%2==0)
	{
		printf("it is a prime number\n");
	}
	else
	{
		printf("it is not a prime\n");
	}
}


#ifndef HELPER_H
#define HELPER_H

// Function prototype
void concatenateArrays(int arr1[], int size1, int arr2[], int size2, int result[], int* resultSize);

#endif


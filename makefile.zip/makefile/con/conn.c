

void concatenateArrays(int arr1[], int size1, int arr2[], int size2, int result[], int* resultSize) {
    int i, j;
    
    for (i = 0; i < size1; i++) {
        result[i] = arr1[i];
    }
    
    for (j = 0; j < size2; j++, i++) {
        result[i] = arr2[j];
    }
    :
    *resultSize = size1 + size2;
}


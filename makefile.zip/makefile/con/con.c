#include <stdio.h>

#define SIZE1 3
#define SIZE2 4

int main() {
    int arr1[SIZE1] = {1, 2, 3};
    int arr2[SIZE2] = {4, 5, 6, 7};
    int result[SIZE1 + SIZE2];
    int resultSize;
    
    concatenateArrays(arr1, SIZE1, arr2, SIZE2, result, &resultSize);
    
    printf("Concatenated Array: ");
    for (int i = 0; i < resultSize; i++) {
        printf("%d ", result[i]);
    }
    printf("\n");
    
    return 0;
}


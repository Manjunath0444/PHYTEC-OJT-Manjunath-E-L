#include<stdio.h>
void demo_com()
{
	char a[20]="srinivas";
	char b[20]="srinivas";
	if(a==b)
		printf("both are same");
	else
		printf("both are not same");
}

#include<stdio.h>
int main()
{
	demo_com();
}

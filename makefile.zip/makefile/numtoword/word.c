#include<stdio.h>
void num_to_word(int n)
{
	int sum=0,r;
	while(n>0)
	{
		r=n%10;
		sum=sum*10+r;
		n=n/10;
	}
	n=sum;
	while(n>0)
	{
		r=n%10;
		switch(r)
		{
			case 1:
				printf("one");
				break;
			case 2:
				printf("two");
				break;
			case 3:
				printf("three");
				break;
			case 4:
				printf("four");
				break;
			case 5:
				printf("five");
			default:
				break;
		}
		n=n/10;
	}
}

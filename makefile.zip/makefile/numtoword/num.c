#include<stdio.h>
int main()
{
	int num;
	printf("enter the number to word\n");
	scanf("%d",&num);
	num_to_word(num);
	return 0;
}


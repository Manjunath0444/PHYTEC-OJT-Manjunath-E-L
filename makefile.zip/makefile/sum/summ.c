#include<stdio.h>
void demo_sum()
{
	int num1,num2,sum;
	printf("enter the number:\n");
	scanf("%d%d",&num1,&num2);
	sum=num1+num2;
	printf("sum of two number is:%d\n",sum);
}



void countevenodd(int arr[],int size,int *evencount,int *oddcount)
{
	for(int i=0;i<size;i++)
	{
		if(arr[i]%2==0)
		{
			(*evencount)++;
		}
		else
		{
			(*oddcount)++;
		}
	}
}

#include<stdio.h>
int main()
{
	int arr[]={1,2,3,4,5};
	int size=sizeof(arr)/sizeof(arr[0]);
	int evencount=0;
	int oddcount=0;
	countevenodd(arr,size,&evencount,&oddcount);
	printf("number is odd elements:%d\n",oddcount);
	printf("number is even elements:%d\n",evencount);
	return 0;
}

#include<stdio.h>
#include<rev.h>
int main()
{
	int num,rev_num;
	printf("enter the number");
	scanf("%d",&num);
	printf("reversed number is %d\n",rev_num);
	return 0;
}

	

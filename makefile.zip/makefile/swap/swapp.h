#ifndef HELPER_H
#define HELPER_H

// Function prototype
void swapArrays(int arr1[], int arr2[], int size);

#endif


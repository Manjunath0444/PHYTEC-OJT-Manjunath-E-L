

void swapArrays(int arr1[], int arr2[], int size) {
    int temp;
    
    for (int i = 0; i < size; i++) {
        temp = arr1[i];
        arr1[i] = arr2[i];
        arr2[i] = temp;
    }
}


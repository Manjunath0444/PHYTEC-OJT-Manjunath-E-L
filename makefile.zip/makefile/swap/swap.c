#include <stdio.h>

#define SIZE 5

int main() {
    int array1[SIZE] = {1, 2, 3, 4, 5};
    int array2[SIZE] = {6, 7, 8, 9, 10};
    
    printf("Before swapping:\n");
    printf("Array 1: ");
    for (int i = 0; i < SIZE; i++) {
        printf("%d ", array1[i]);
    }
    printf("\n");
    
    printf("Array 2: ");
    for (int i = 0; i < SIZE; i++) {
        printf("%d ", array2[i]);
    }
    printf("\n");
    
    swapArrays(array1, array2, SIZE);
    
    printf("After swapping:\n");
    printf("Array 1: ");
    for (int i = 0; i < SIZE; i++) {
        printf("%d ", array1[i]);
    }
    printf("\n");
    
    printf("Array 2: ");
    for (int i = 0; i < SIZE; i++) {
        printf("%d ", array2[i]);
    }
    printf("\n");
    
    return 0;
}


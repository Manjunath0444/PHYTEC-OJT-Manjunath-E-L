#include<stdio.h>
int main()
{
	int arr[]={1,2,3,4,5,6};
	int size=sizeof(arr)/sizeof(arr[0]);
	int *ptr=arr;
	int newsize=removeduplicates(ptr,size);
	printf("array after removing duplicates:\n");
	for(int i=0;i<newsize;i++)
	{
		printf("%d\n",*(ptr+i));
	}
	return 0;
}


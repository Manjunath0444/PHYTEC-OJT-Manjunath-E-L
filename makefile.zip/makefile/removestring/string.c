int removeduplicates(int *arr,int size)
{
	int *result=arr;
	if(size<2)
	{
		return size;
	}
	int index=1;
	for(int i=1;i<size;i++)
	{
		if(*(arr+i)!=*(arr+i-i))
		{
			*(result+index)=*(arr+i);
			index++;
		}
	}
	return index;
}


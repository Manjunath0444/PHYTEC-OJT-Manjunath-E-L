#include<stdio.h>
int main()
{
	int arr[]={1,-2,3,-4,5};
	int size=sizeof(arr)/sizeof(arr[0]);
	int *ptr=arr;
	int positivecount=0;
	int negativecount=0;
	countpositivenegative(ptr,size,&positivecount,&negativecount);
	printf("positive numbers:%d\n",positivecount);
	printf("negative numbers:%d\n",negativecount);
	return 0;
}


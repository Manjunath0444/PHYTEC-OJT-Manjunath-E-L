void countpositivenegative(int *arr,int size,int *positivecount,int *negativecount)
{
	for(int i=0;i<size;i++)
	{
		if(*(arr+i)>0)
		{
			(*positivecount)++;
		}
		else if(*(arr+i)<0)
		{
			(*negativecount)++;
		}
	}
}

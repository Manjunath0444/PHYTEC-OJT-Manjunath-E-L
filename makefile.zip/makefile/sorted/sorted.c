#include<stdio.h>
int main()
{
	int arr[]={1,2,3,4,5,6};
	int size=sizeof(arr)/sizeof(arr[0]);
	int sorted= issorted(arr,size);
	if(sorted)
	
		printf("array is sorted\n");
		else
		printf("array is not sorted\n");
		return 0;

}

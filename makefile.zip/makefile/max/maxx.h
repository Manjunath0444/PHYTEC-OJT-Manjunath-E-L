#ifndef HELPER_H
#define HELPER_H

// Function prototype
int findMax(int arr[], int size);

#endif


#include<stdio.h>

#define SIZE 5

int main() {
    int numbers[SIZE];
    
    printf("Enter %d numbers:\n", SIZE);
    for (int i = 0; i < SIZE; i++) {
        scanf("%d", &numbers[i]);
    }
    
    int max = findMax(numbers, SIZE);
    
    printf("The maximum number is: %d\n", max);
    
    return 0;
}


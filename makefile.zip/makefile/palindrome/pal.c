#include<stdio.h>
#include<unistd.h>
int main()
{
	revnum_demo();
}


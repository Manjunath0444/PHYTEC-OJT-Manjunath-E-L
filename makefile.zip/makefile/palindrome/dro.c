#include<stdio.h>
void revnum_demo()
{
	int num,rev_num=0,rem,tempnum=0;
	printf("enter the number::\n");
	scanf("%d",&num);
	while(num)
	{
		rem=num%10;
		rev_num=rev_num*10+rem;
		num=num/10;
	}
	printf("reverse number=%d\n",rev_num);
	tempnum=num;


	if(tempnum=rev_num)
		printf("given number is a palindrome:\n");
	else
		printf("not a palindrome\n");

}

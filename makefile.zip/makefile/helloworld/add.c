#include<stdio.h>
void main()
{
	int a,b,c;
	printf("enter the 3 integers::");
	scanf("%d,%d",&a,&b);
	c=a+b;
	printf("sum of integer is=%d\n",c);
}

#ifndef HELPER_H
#define HELPER_H

// Function prototype
void copyArray(int source[], int size, int destination[]);

#endif


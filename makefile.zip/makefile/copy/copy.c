#include <stdio.h>

#define SIZE 5

int main() {
    int sourceArray[SIZE] = {1, 2, 3, 4, 5};
    int destinationArray[SIZE];
    
    copyArray(sourceArray, SIZE, destinationArray);
    
    printf("Source Array: ");
    for (int i = 0; i < SIZE; i++) {
        printf("%d ", sourceArray[i]);
    }
    printf("\n");
    
    printf("Destination Array: ");
    for (int i = 0; i < SIZE; i++) {
        printf("%d ", destinationArray[i]);
    }
    printf("\n");
    
    return 0;
}




void copyArray(int source[], int size, int destination[]) {
    for (int i = 0; i < size; i++) {
        destination[i] = source[i];
    }
}


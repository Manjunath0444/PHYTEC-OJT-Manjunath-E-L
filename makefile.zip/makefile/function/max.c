#include<stdio.h>
int main()
{
	int r1,r2,r3,r4,r5;
	r1=4;
	r2=6;
	r3=mymul(r1,r2);
	r4=mysum(r1,r2);
	r5=mymax(r3,r4);
	printf("%d\n",r3);
	printf("%d\n",r4);
	printf("%d\n",r5);
}

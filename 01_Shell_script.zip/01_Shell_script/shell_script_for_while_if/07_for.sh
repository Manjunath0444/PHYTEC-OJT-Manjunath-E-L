#!/bin/bash

for i in $(seq 0 2 20)
do
	echo "Welcome $i times"
done

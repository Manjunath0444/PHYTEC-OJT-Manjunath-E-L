#!/bin/bash
for (( ; ; ))
do
	echo "infinite loops [ hit CTRL+C to stop ]"
	sleep 1
done

#!/bin/bash

for i in `seq 1 10`
do
	echo $i
done


## cp multiple files
## for i in `seq 1 100 ;do cp test.txt "test_${1}.txt"; done
